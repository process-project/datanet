ENV['RACK_ENV'] ||= :test

require File.expand_path('../application', __FILE__)